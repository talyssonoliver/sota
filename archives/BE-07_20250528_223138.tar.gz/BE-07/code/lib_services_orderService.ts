import { supabase } from '../supabase/client';
import { Order, CreateOrderData, UpdateOrderData, OrderStatus } from '../types/order';

export class OrderService {
  /**
   * Create a new order
   */
  async createOrder(data: CreateOrderData): Promise<Order> {
    const { data: order, error } = await supabase
      .from('orders')
      .insert([{
        ...data,
        status: 'pending',
        created_at: new Date().toISOString()
      }])
      .select(`
        *,
        customer:customers(id, name, email),
        order_items:order_items(
          id,
          quantity,
          unit_price,
          product:products(id, name, price)
        )
      `)
      .single();

    if (error) {
      throw new Error(`Failed to create order: ${error.message}`);
    }

    return order;
  }

  /**
   * Get order by ID with full details
   */
  async getOrderById(id: string): Promise<Order | null> {
    const { data: order, error } = await supabase
      .from('orders')
      .select(`
        *,
        customer:customers(id, name, email),
        order_items:order_items(
          id,
          quantity,
          unit_price,
          product:products(id, name, price, description)
        )
      `)
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null; // No rows returned
      throw new Error(`Failed to get order: ${error.message}`);
    }

    return order;
  }

  /**
   * Update order status and information
   */
  async updateOrder(id: string, data: UpdateOrderData): Promise<Order> {
    const { data: order, error } = await supabase
      .from('orders')
      .update({
        ...data,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select(`
        *,
        customer:customers(id, name, email)
      `)
      .single();

    if (error) {
      throw new Error(`Failed to update order: ${error.message}`);
    }

    return order;
  }

  /**
   * Get orders by customer ID
   */
  async getOrdersByCustomerId(customerId: string): Promise<Order[]> {
    const { data: orders, error } = await supabase
      .from('orders')
      .select(`
        *,
        customer:customers(id, name, email),
        order_items:order_items(
          id,
          quantity,
          unit_price,
          product:products(id, name, price)
        )
      `)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to get customer orders: ${error.message}`);
    }

    return orders || [];
  }

  /**
   * Update order status
   */
  async updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
    return this.updateOrder(id, { status });
  }

  /**
   * Get orders with filtering and pagination
   */
  async getOrders(options?: {
    status?: OrderStatus;
    customerId?: string;
    dateFrom?: string;
    dateTo?: string;
    page?: number;
    limit?: number;
  }): Promise<{ orders: Order[]; total: number }> {
    let query = supabase
      .from('orders')
      .select(`
        *,
        customer:customers(id, name, email)
      `, { count: 'exact' });

    // Apply filters
    if (options?.status) {
      query = query.eq('status', options.status);
    }

    if (options?.customerId) {
      query = query.eq('customer_id', options.customerId);
    }

    if (options?.dateFrom) {
      query = query.gte('created_at', options.dateFrom);
    }

    if (options?.dateTo) {
      query = query.lte('created_at', options.dateTo);
    }

    // Apply pagination
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    query = query.range(from, to).order('created_at', { ascending: false });

    const { data: orders, error, count } = await query;

    if (error) {
      throw new Error(`Failed to get orders: ${error.message}`);
    }

    return {
      orders: orders || [],
      total: count || 0
    };
  }
}

export const orderService = new OrderService();