export { customerService, CustomerService } from './customerService';
export { orderService, OrderService } from './orderService';

// Re-export types for convenience
export type { Customer, CreateCustomerData, UpdateCustomerData } from '../types/customer';
export type { Order, CreateOrderData, UpdateOrderData, OrderStatus } from '../types/order';