import { supabase } from '../supabase/client';
import { Customer, CreateCustomerData, UpdateCustomerData } from '../types/customer';

export class CustomerService {
  /**
   * Create a new customer
   */
  async createCustomer(data: CreateCustomerData): Promise<Customer> {
    const { data: customer, error } = await supabase
      .from('customers')
      .insert([data])
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create customer: ${error.message}`);
    }

    return customer;
  }

  /**
   * Get customer by ID
   */
  async getCustomerById(id: string): Promise<Customer | null> {
    const { data: customer, error } = await supabase
      .from('customers')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null; // No rows returned
      throw new Error(`Failed to get customer: ${error.message}`);
    }

    return customer;
  }

  /**
   * Update customer information
   */
  async updateCustomer(id: string, data: UpdateCustomerData): Promise<Customer> {
    const { data: customer, error } = await supabase
      .from('customers')
      .update(data)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update customer: ${error.message}`);
    }

    return customer;
  }

  /**
   * Delete customer
   */
  async deleteCustomer(id: string): Promise<void> {
    const { error } = await supabase
      .from('customers')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete customer: ${error.message}`);
    }
  }

  /**
   * Get all customers with optional filtering
   */
  async getCustomers(filters?: { email?: string; status?: string }): Promise<Customer[]> {
    let query = supabase.from('customers').select('*');

    if (filters?.email) {
      query = query.ilike('email', `%${filters.email}%`);
    }

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }

    const { data: customers, error } = await query;

    if (error) {
      throw new Error(`Failed to get customers: ${error.message}`);
    }

    return customers || [];
  }
}

export const customerService = new CustomerService();